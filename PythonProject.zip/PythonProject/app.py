from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///training.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class TrainingPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    goal = db.Column(db.String(100), nullable=False)
    lifestyle = db.Column(db.String(100), nullable=False)
    body_focus = db.Column(db.String(100), nullable=False)
    body_shape = db.Column(db.String(100), nullable=False)
    current_weight = db.Column(db.Float, nullable=False)
    target_weight = db.Column(db.Float, nullable=False)
    height = db.Column(db.Float, nullable=False)
    time = db.Column(db.Integer, nullable=False)
    plan = db.Column(db.Text, nullable=False)

@app.route('/')
def home():
    return render_template('home.html', title='Strona Główna')

@app.route('/user-form', methods=['GET', 'POST'])
def user_form():
    if request.method == 'POST':
        age = int(request.form.get('age', 0))
        gender = request.form.get('gender', '')
        goal = request.form.get('goal', '')
        lifestyle = request.form.get('lifestyle', '')
        body_focus = request.form.get('body_focus', '')
        body_shape = request.form.get('body_shape', '')
        current_weight = float(request.form.get('current_weight', 0))
        target_weight = float(request.form.get('target_weight', 0))
        height = float(request.form.get('height', 0))
        time = int(request.form.get('time', 0))

        plan = f"Cel: {goal}, Tryb życia: {lifestyle}. Skupienie: {body_focus}, Sylwetka: {body_shape}. Zalecany czas treningów: {time} godzin tygodniowo."

        new_plan = TrainingPlan(
            age=age, gender=gender, goal=goal, lifestyle=lifestyle,
            body_focus=body_focus, body_shape=body_shape,
            current_weight=current_weight, target_weight=target_weight,
            height=height, time=time, plan=plan
        )
        db.session.add(new_plan)
        db.session.commit()

        response = {
            "age": age, "gender": gender, "goal": goal, "lifestyle": lifestyle,
            "body_focus": body_focus, "body_shape": body_shape,
            "current_weight": current_weight, "target_weight": target_weight,
            "height": height, "time": time, "plan": plan
        }
        return render_template('response.html', title='Twój Plan', response=response)

    return render_template('user_form.html', title='Ankieta Użytkownika')

@app.route('/create-plan', methods=['GET', 'POST'])
def create_plan():
    if request.method == 'POST':
        email = request.form.get('email', '')
        comment = request.form.get('comment', '')
        return render_template('thank_you.html', title='Dziękujemy!', email=email)

    return render_template('create_plan.html', title='Personalny Plan')

@app.route('/all-plans')
def all_plans():
    plans = TrainingPlan.query.all()
    return render_template('all_plans.html', title='Wszystkie Plany', plans=plans)

if __name__ == '__main__':
    with app.app_context():
        db.drop_all()
        db.create_all()
    app.run(debug=True)
